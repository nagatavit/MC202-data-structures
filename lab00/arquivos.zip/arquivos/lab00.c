#include <stdio.h>

int main(void)
{
    char nome[100];
    printf("Digite seu nome: ");
    scanf("%s", nome);
    printf("Bem-vind@ a MC202, %s!\n", nome);
}
