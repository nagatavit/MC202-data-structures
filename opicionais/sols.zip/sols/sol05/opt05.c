/*

Este é um exemplo de solução para o exercício opcional, então não quer dizer que
é a única ou melhor maneira de resolvê-lo.

Você pode ler e estudar este código, mas não pode guardá-lo, arquivá-lo ou
distribui-lo de qualquer maneira.

Não cópie este código. Trechos de códigos copiados (mesmo que tenham
modificações) serão considerados plágio.

*/

#include <stdio.h>
#include <math.h>

/*Calcula o maximo divisor comum entre a e b */
int mdc(int a, int b)
{
    if (b == 0)
        return a;
    else
        return mdc(b, a % b);
}

/*calcula o fatorial de n */
double fatorial(int n)
{
    if (n == 0)
        return 1;
    else
        return n * fatorial(n - 1);

}

/*calcula a combinacao de n elementos com s sub-elementos */
double combinacao(int n, int s)
{
    if (s <= n)
        return fatorial(n) / (fatorial(s) * fatorial(n - s));
    //se o numero de sub elementos eh maior que n soh existe uma forma de combinar
    else
        return 1;
}

/*
   determina quantos times eh possivel formar de forma
   que todos os setores de administracao, operacoes e vendas
   possuam o mesmo numero de times
 */
int separa_times(int adm, int op, int vend)
{

    int ntimes = 0;;
    ntimes = mdc(adm, mdc(op, vend));   //o numero de times eh o mdc(adm,op,vend)
    return ntimes;
}

/*
   Determina o valor presente liquido de uma operacao financeira
   que ira durar t meses, com um custo inicial FC0, um rendimento
   mensal de FCsum ajutado pela taxa minima de atratividade j
 */
float VPLsum(float FC0, float FCsum, float j, int t)
{
    //no inicio do projeto determina o custo inicial
    if (t == 0)
        return 0 - FC0;
    //determina o Valor de t e soma com os valores de tempo passados
    else
        return (FCsum / powf((1 + j), t)) + VPLsum(FC0, FCsum, j, t - 1);
}

int main(int argc, char **argv)
{
    int opcao = 0;              // opcao a ser escolhida no menu
    int adm = 0, op = 0, vend = 0;  // setores de administracao, operacao e vendas
    int ntimes = 0, mtimes = 0, nequipes = 0;   // quantidade de times em cada setor, quantidade de times em cada equipe, quantidade de equipes
    double comb = 0;            // numero possivel de combinacoes de equipes
    int t = 0;                  // quantidade de meses que o projeto ira durar
    float FC0 = 0, Cin = 0, Cout = 0;   // custo inicial do projeto, entrada de caixa por mes, saida de caixa por mes
    float FCsum = 0, VPL = 0, j = 0;    // fluxo de caixa do projeto, valor presente liquido, e taxa minima de atratividade

    while (1) {
        //imprime menu
        printf("1 - Times\n2 - Equipes\n3 - VPL\n4 - Sair\n");
        scanf("%d", &opcao);

        switch (opcao) {
        case 1:
            scanf("%d %d %d", &adm, &op, &vend);
            if (adm > 0 && op > 0 && vend > 0) {
                ntimes = separa_times(adm, op, vend);

                /*imprime resultados */
                printf("Numero de times por setor eh %d\n", ntimes);
                printf("Administracao: %d membros por time\n", adm / ntimes);
                printf("Operacional: %d membros por time\n", op / ntimes);
                printf("Vendas: %d membros por time\n", vend / ntimes);
            } else {
                printf("Entrada invalida!\n");
            }
            break;

        case 2:
            scanf("%d %d", &ntimes, &mtimes);
            if (ntimes > 0 && mtimes > 0) {
                nequipes = ntimes / mtimes;
                //caso seja possivel formar equipes com mtimes de cada setor
                if (ntimes % mtimes == 0) {
                    comb = combinacao(ntimes, mtimes) * combinacao(ntimes, mtimes) * combinacao(ntimes, mtimes);

                    printf("O numero de equipes eh %d\n", nequipes);
                    printf("Pode-se combinar as equipes de %.5e formas diferentes\n", comb);

                    //caso nao seja possivel formar equipes com mtimes de cada setor
                } else {
                    printf("Divisao invalida!\n");
                }
            } else {
                printf("Entrada invalida!\n");
            }
            break;

        case 3:
            scanf("%d %f %d", &nequipes, &j, &t);
            //caso valores estejam dentro do aceitavel
            if (nequipes > 0 && t > 0 && j >= 0.01 && j <= 1) {

                FC0 = nequipes * 2500;  // custo inicial de 2500 por equipe
                Cin = nequipes * 1000;  // entrada de caixa de 1000 por equipe
                Cout = nequipes * 450;  // saida de caixa de 450 por equipe
                FCsum = Cin - Cout; // fluxo de caixa eh a entrada de caixa menos a saida de caixa

                VPL = VPLsum(FC0, FCsum, j, t); //determina o valor presente liquido do projeto

                //caso seja positivo o projeto eh viavel
                if (VPL > 0)
                    printf("VPL igual a %.2f: projeto viavel!\n", VPL);
                //do contrario o projeto eh inviavel
                else
                    printf("VPL igual a %.2f: projeto inviavel!\n", VPL);
            } else {
                printf("Entrada invalida!\n");
            }
            break;

        case 4:
            return 0;

        default:
            break;
        }
    }

    return 0;
}
