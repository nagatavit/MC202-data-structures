/*

Este é um exemplo de solução para o exercício opcional, então não quer dizer que
é a única ou melhor maneira de resolvê-lo.

Você pode ler e estudar este código, mas não pode guardá-lo, arquivá-lo ou
distribui-lo de qualquer maneira.

Não cópie este código. Trechos de códigos copiados (mesmo que tenham
modificações) serão considerados plágio.

*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX 1125

struct cliente {
   char nome[30];
   int telefone;
};

struct cliente dados[MAX];

void selection_sort(int tam) { /*ordena os dados*/

   int i, j, min;
   struct cliente aux;

   for (i = 0; i < (tam-1); i++)
   {
      min = i;

      for (j = (i+1); j < tam; j++) {
         if(dados[j].telefone < dados[min].telefone)
            min = j;
      }
      if (dados[i].telefone != dados[min].telefone) {
         aux = dados[i];
         dados[i] = dados[min];
         dados[min] = aux;
      }
   }
}

/*realiza a leitura dos participantes*/
int ler(int i) {

   scanf(" %s %d", dados[i].nome, &dados[i].telefone);

   return strcmp("fim", dados[i].nome);
}

int main() {
   int n, k;

   for (n = 0; ler(n); ++n);

   selection_sort(n);

   k = dados[n].telefone-1;

   printf("%s %d\n", dados[k].nome, dados[k].telefone);

   return EXIT_SUCCESS;
}
