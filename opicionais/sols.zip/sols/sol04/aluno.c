/*

Este é um exemplo de solução para o exercício opcional, então não quer dizer que
é a única ou melhor maneira de resolvê-lo.

Você pode ler e estudar este código, mas não pode guardá-lo, arquivá-lo ou
distribui-lo de qualquer maneira.

Não cópie este código. Trechos de códigos copiados (mesmo que tenham
modificações) serão considerados plágio.

*/

#include "aluno.h"

void ler_aluno(Aluno *aluno)
{
    int i;

    scanf("%s %s", aluno->nome, aluno->sobrenome);
    scanf("%lf", &aluno->media);
    scanf("%d", &aluno->num_disciplinas);

    for( i = 0; i < aluno->num_disciplinas; ++i )
        scanf(" %s", aluno->disciplinas[i]);
}
