/*

Este é um exemplo de solução para o exercício opcional, então não quer dizer que
é a única ou melhor maneira de resolvê-lo.

Você pode ler e estudar este código, mas não pode guardá-lo, arquivá-lo ou
distribui-lo de qualquer maneira.

Não cópie este código. Trechos de códigos copiados (mesmo que tenham
modificações) serão considerados plágio.

*/

#include "lab01.h"

#define AUMENTO1 0.15
#define AUMENTO2 0.10
#define AUMENTO3 0.05
#define SEM_AUMENTO 0
#define CMP(a, b) ( (a >= b - 0.01) && (a <= b + 0.1) )

void ler_professores(Professor *professores, int n)
{
    int i;
    for(i = 0; i < n; ++i)
        ler_professor(&professores[i]);
}

void ler_alunos(Aluno *alunos, int n)
{
    int i;
    for (i = 0; i < n; ++i)
        ler_aluno(&alunos[i]);
}

void aplicar_aumento(Professor *professores, int np, Aluno *alunos, int na)
{
    int i, j, k;
    double aumentos[100];
    for (i = 0; i < np; ++i)
        aumentos[i] = SEM_AUMENTO;

    for (i = 0; i < np; ++i)
    {
        double menor = 10.00;
        for (j = 0; j < na; ++j) {
            for (k = 0; k < alunos[j].num_disciplinas; ++k) {
                if(strcmp(professores[i].disciplina, alunos[j].disciplinas[k]) == 0 && alunos[j].media < menor)
                    menor = alunos[j].media;
            }
        }

        if(menor > 9.999)
            aumentos[i] = AUMENTO1;
        else if(menor > 8.999 && menor < 10.00)
            aumentos[i] = AUMENTO2;
        else if(menor > 8.499 && menor < 9.00)
            aumentos[i] = AUMENTO3;
        else if(menor < 8.50)
            aumentos[i] = SEM_AUMENTO;
    }


    for (i = 0; i < np; ++i)
        aumento(professores+i, aumentos[i]);
}

void imprimir_professores(Professor *professores, int np)
{
    int i;
    for (i = 0; i < np; ++i)
        printf("%s %s %.2f\n", professores[i].nome, professores[i].sobrenome, professores[i].salario);
}
