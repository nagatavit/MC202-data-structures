/*

Este é um exemplo de solução para o exercício opcional, então não quer dizer que
é a única ou melhor maneira de resolvê-lo.

Você pode ler e estudar este código, mas não pode guardá-lo, arquivá-lo ou
distribui-lo de qualquer maneira.

Não cópie este código. Trechos de códigos copiados (mesmo que tenham
modificações) serão considerados plágio.

*/

#include "professor.h"

void ler_professor(Professor *professor)
{
    scanf("%s %s", professor->nome, professor->sobrenome);
    scanf("%lf", &professor->salario);
    scanf("%s", professor->disciplina);
}

void aumento(Professor *professor, double porcentagem)
{
    professor->salario += professor->salario*porcentagem;
}
