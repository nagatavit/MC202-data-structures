/*

Este é um exemplo de solução para o exercício opcional, então não quer dizer que
é a única ou melhor maneira de resolvê-lo.

Você pode ler e estudar este código, mas não pode guardá-lo, arquivá-lo ou
distribui-lo de qualquer maneira.

Não cópie este código. Trechos de códigos copiados (mesmo que tenham
modificações) serão considerados plágio.

*/

# include <stdio.h>

int main() {
    char sexo = ' ';                            // Sexo (M ou F) do paciente
    int idade = 0;                              // Idade (em anos) do paciente
    float peso = 0;                             // Peso (em kg) do paciente
    float altura = 0;                           // Altura (em m) do paciente
    float colesterol = 0;                       // Nivel de colesterol (em mg) do paciente
    int opcao = 0;                              // Opcao de impressao na tela
    float IMC = 0;                              // IMC do paciente
    float TMB = 0;                              // TMB do paciente
    int valido = 1;                             // Verdadeiro para dados validos; falso, caso contrario

    scanf("%c", &sexo);                  // Le e armazena o caracter relativo ao sexo do paciente
    scanf("%d", &idade);                 // Le e armazena o inteiro relativo a idade do paciente
    scanf("%f", &peso);                  // Le e armazena o valor relativo ao peso do paciente
    scanf("%f", &altura);                // Le e armazena o valor relativo a altura do paciente
    scanf("%f", &colesterol);            // Le e armazena o valor relativo ao nivel de colesterol do paciente
    scanf("%d", &opcao);                 // Le e armazena o valor relativo a opcao de impressao na tela

    // Verifica a validade dos valores informados pelo usuario
    if(sexo != 'M' && sexo != 'F') {
        printf("Sexo invalido!\n");
        valido = 0;
    }
    if(idade < 18) {
        printf("Idade invalida!\n");
        valido = 0;
    }
    if(peso <= 0) {
        printf("Peso invalido!\n");
        valido = 0;
    }
    if(altura <= 0) {
        printf("Altura invalida!\n");
        valido = 0;
    }
    if(colesterol <= 0) {
        printf("Nivel de colesterol invalido!\n");
        valido = 0;
    }
    if(opcao != 1 && opcao != 2 && opcao != 3 && opcao != 4 && opcao != 5 && opcao != 6 && opcao != 7) {
        printf("Opcao de impressao invalida!\n");
        valido = 0;
    }

    // Aborta o programa se algum dado informado pelo usuario for invalido
    if (!valido)
        return 0;

    // Imprime os dados do paciente
    printf("Sexo: %c\n", sexo);
    printf("Idade: %d anos\n", idade);
    printf("Peso: %.2f kg\n", peso);
    printf("Altura: %.2f m\n", altura);
    printf("Colesterol: %.2f mg\n\n", colesterol);

    // Se a opcao contiver o IMC, calcula, classifica e imprime o indice
    if (opcao == 1 || opcao == 4 || opcao == 5 || opcao == 7) {
        // Calcula o IMC e imprime o resultado
        IMC = peso/(altura*altura);
        printf("IMC: %.1f -> ", IMC);

        // Classifica o IMC do paciente e imprime o resultado
        if(IMC <= 18.5)
            printf("SUBNUTRICAO\n");
        else {
            if(IMC < 25.0)
                printf("PESO SAUDAVEL\n");
            else {
                if(IMC < 30.0)
                    printf("SOBREPESO\n");
                else {
                    if(IMC < 35.0)
                        printf("OBESIDADE GRAU 1\n");
                    else {
                        if(IMC < 40.0)
                            printf("OBESIDADE GRAU 2\n");
                        else
                            printf("OBESIDADE GRAU 3\n");
                    }
                }
            }
        }
    }

    // Se a opcao contiver o TMB, calcula, classifica e imprime o indice
    if (opcao == 2 || opcao == 4 || opcao == 6 || opcao == 7) {
        // Calcula o TMB e imprime o resultado
        if(sexo == 'M')
            TMB = 66.47 + 13.75*peso + 5.00*altura*100 - 6.76*idade;
        else
            TMB = 655.10 + 9.56*peso + 1.85*altura*100 - 4.68*idade;
        printf("TMB = %.2f kcal/dia\n", TMB);
    }

    // Se a opcao contiver o colesterol, classifica e imprime o indice
    if (opcao == 3 || opcao == 5 || opcao == 6 || opcao == 7) {
        // Imprime o nivel de colesterol do paciente
        printf("Colesterol: %.2f mg -> ", colesterol);

        // Classifica o nivel de colesterol do paciente e imprime o resultado
        if(idade <= 29) {
            if(colesterol <= 180)
                printf("NIVEL BOM\n");
            else {
                if(colesterol <= 200)
                    printf("RISCO BAIXO\n");
                else {
                    if(colesterol <= 220)
                        printf("RISCO MODERADO\n");
                    else
                        printf("RISCO ALTO\n");
                }
            }
        } else {
            if(idade <= 39) {
                if(colesterol <= 200)
                    printf("NIVEL BOM\n");
                else {
                    if(colesterol <= 220)
                        printf("RISCO BAIXO\n");
                    else {
                        if(colesterol <= 240)
                            printf("RISCO MODERADO\n");
                        else
                            printf("RISCO ALTO\n");
                    }
                }
            } else {
                if(colesterol <= 200)
                    printf("NIVEL BOM\n");
                else {
                    if(colesterol <= 240)
                        printf("RISCO BAIXO\n");
                    else {
                        if(colesterol <= 260)
                            printf("RISCO MODERADO\n");
                        else
                            printf("RISCO ALTO\n");
                    }
                }
            }
        }
    }

    return 0;
}
