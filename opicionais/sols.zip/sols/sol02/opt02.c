/*

Este é um exemplo de solução para o exercício opcional, então não quer dizer que
é a única ou melhor maneira de resolvê-lo.

Você pode ler e estudar este código, mas não pode guardá-lo, arquivá-lo ou
distribui-lo de qualquer maneira.

Não cópie este código. Trechos de códigos copiados (mesmo que tenham
modificações) serão considerados plágio.

*/

#include <stdio.h>
#include <stdlib.h>

void imprimir_arvore(char *vetor, int esq, int dir, int nivel, int tam, int k) {
    int i;
    if (esq != dir) {
        imprimir_arvore(vetor, (esq + dir) / 2 + 1, dir, nivel + 1, tam, k);
        for(i=0; i < nivel * 5; i++)
            printf("-");
        printf("%c", vetor[(esq + dir) / 2]);
        printf("\n");
        imprimir_arvore(vetor, esq, (esq + dir) / 2, nivel + 1, tam , k);
    }
}

int potencia(int b, int k) {
    if (k == 0)
        return 1;
    else
        return b * potencia(b, k - 1);
}

int main(void) {
    int i, k, tam;
    char *vetor;
    scanf("%d", &k);
    tam = potencia(2, k) - 1;
    vetor = malloc(sizeof(char) * tam);
    for (i=0; i < tam; i++)
        scanf(" %c", &vetor[i]);
    imprimir_arvore(vetor, 0, tam, 0, tam, k);
    free(vetor);
    return 0;
}
